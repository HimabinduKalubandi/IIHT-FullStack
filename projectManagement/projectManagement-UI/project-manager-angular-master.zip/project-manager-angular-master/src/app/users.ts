export const users = [
  {
    employeeId: 899,
    firstName: 'Jim',
    lastName: 'Horton',
    editMode: false
  },
  {
    employeeId: 585,
    firstName: 'Tim',
    lastName: 'Cook',
    editMode: false
  },
  {
    employeeId: 468,
    firstName: 'Jeff',
    lastName: 'Bezos',
    editMode: false
  }
];